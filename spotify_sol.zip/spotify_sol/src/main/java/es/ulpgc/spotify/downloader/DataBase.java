
package es.ulpgc.spotify.downloader;

import java.sql.*;


public class DataBase {
    public DataBase(){};

    public Connection connect(String Spotify) {
        // SQLite connection string
        Connection conn = null;
        String url = "jdbc:sqlite:" + Spotify;

        try {
            conn = DriverManager.getConnection(url);
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return conn;
    }

    public void createNewDatabase(String fileName) {

        String url = "jdbc:sqlite:" + fileName;

        try (Connection conn = DriverManager.getConnection(url)) {
            if (conn != null) {
                DatabaseMetaData meta = conn.getMetaData();
                System.out.println("The driver name is " + meta.getDriverName());
                System.out.println("A new database has been created.");
            }

        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    public void createNewTable(){
        String url = "jdbc:sqlite:C:\\Users\\fenix\\IdeaProjects\\spotify_sol\\Spotify.db";

        String sql = "CREATE TABLE IF NOT EXISTS Artist (\n"
                + "	artist_name text,\n"
                + "	id text PRIMARY KEY\n"
                + ");";
        String albums_table = "CREATE TABLE IF NOT EXISTS Albums (\n"
                + "	album_name text,\n"
                + "	album_id text PRIMARY KEY,\n"
                + "	album_tracks text\n"
                + ");";
        String songs_table = "CREATE TABLE IF NOT EXISTS Songs (\n"
                + "	song_name text,\n"
                + "	song_id text PRIMARY KEY\n"
                + ");";

        try (Connection conn = DriverManager.getConnection(url);
             Statement stmt = conn.createStatement()) {
            stmt.execute(sql);
            stmt.execute(albums_table);
            stmt.execute(songs_table);
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    public void insert_to_artist(String artist_name, String artist_id, String dbPath) {
        String sql = "INSERT INTO Artist(artist_name,id) VALUES(?,?)";

        try (Connection conn = this.connect(dbPath);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, artist_name);
            pstmt.setString(2, String.valueOf(artist_id));
            pstmt.executeUpdate();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }

    }

    public void insert_to_album(String album_name, String album_id, String album_tracks, String dbPath) {
        String album_connect = "INSERT INTO Albums(album_name, album_id, album_tracks) VALUES(?,?,?)";

        try (Connection conn = this.connect(dbPath);
             PreparedStatement pstmt = conn.prepareStatement(album_connect)) {
            pstmt.setString(1, album_name);
            pstmt.setString(2, String.valueOf(album_id));
            pstmt.setString(3, album_tracks);

            pstmt.executeUpdate();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }

    }

    public void insert_to_songs(String song_name, String song_id, String dbPath) {
        String song_connect = "INSERT INTO Songs(song_name, song_id) VALUES(?,?)";

        try (Connection conn = this.connect(dbPath);
             PreparedStatement pstmt = conn.prepareStatement(song_connect)) {
            pstmt.setString(1, song_name);
            pstmt.setString(2, String.valueOf(song_id));

            pstmt.executeUpdate();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }

    }
}



