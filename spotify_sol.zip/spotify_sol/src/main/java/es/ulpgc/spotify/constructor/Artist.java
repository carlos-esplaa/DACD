package es.ulpgc.spotify.constructor;

public class Artist {
    private String artist_name;
    private String artist_id;

    public Artist(String artist_name, String artist_id){
        this.artist_name = artist_name;
        this.artist_id = artist_id;
    }

    public String getArtist_name() {
        return artist_name;
    }

    public String getArtist_id() {
        return artist_id;
    }

    public void setArtist_name(String artist_name) {
        this.artist_name = artist_name;
    }

    public void setArtist_id(String artist_id) {    this.artist_id = artist_id;    }

    public Artist(){}

    @Override
    public String toString() {
        return "Artist{" +
                "artist_name='" + artist_name + '\'' +
                ", artist_id='" + artist_id + '\'' +
                '}';
    }
}
