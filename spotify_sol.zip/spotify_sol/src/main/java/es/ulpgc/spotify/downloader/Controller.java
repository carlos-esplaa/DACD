package es.ulpgc.spotify.downloader;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import es.ulpgc.spotify.constructor.Album;
import es.ulpgc.spotify.constructor.Artist;
import es.ulpgc.spotify.constructor.Song;

import java.util.Map;

public class Controller {

    public Controller() {};

    final Map<String, String> artists = Map.of(
            "Natos y Waor", "1QJbbsxg2wqidJj51d3otw",
            "El vega", "4x3Vb1a9yggcqEuRljiLeB",
            "Aristides Moreno", "7ra1giuH0fQcE9s89h8hj7",
            "Fito y Fitipaldis", "1tZ99AnqyjgrmPwLfGU5eo",
            "El Jincho", "2w1wJcGdJQ4Lw08oKBnDsw");

        public void controller() throws Exception {
            SpotifyAccessor accessor = new SpotifyAccessor();
            DataBase dataBase = new DataBase();
            dataBase.createNewDatabase("Spotify.db");

            String dbPath = "C:\\Users\\fenix\\IdeaProjects\\spotify_sol\\Spotify.db";
            dataBase.connect(dbPath);
            dataBase.createNewTable();

            for (String id : artists.values()) {
                Artist artist = new Artist();
                String res = accessor.get("/artists/" + id, Map.of());
                JsonObject jsonObject0 = new Gson().fromJson(res, JsonObject.class);
                artist.setArtist_name(jsonObject0.get("name").getAsString());
                artist.setArtist_id(jsonObject0.get("id").getAsString());

                dataBase.insert_to_artist(artist.getArtist_name(), artist.getArtist_id(), dbPath);

                String answer = accessor.get("/artists/" + id + "/albums", Map.of());
                JsonObject jsonObject = new Gson().fromJson(answer, JsonObject.class);
                JsonArray items = jsonObject.get("items").getAsJsonArray();

                for (JsonElement item : items) {
                    if (item.getAsJsonObject().get("album_type").getAsString().equals("album")) {
                        Album album = new Album();

                        album.setAlbum_name(item.getAsJsonObject().get("name").getAsString());
                        album.setTotal_tracks(item.getAsJsonObject().get("total_tracks").getAsString());
                        album.setId(item.getAsJsonObject().get("id").getAsString());

                        dataBase.insert_to_album(album.getAlbum_name(), album.getId(), album.getTotal_tracks(), dbPath);
                    }


                    String response = accessor.get("/albums/" + item.getAsJsonObject().get("id").getAsString() + "/tracks", Map.of());
                    JsonObject jsonObject1 = new Gson().fromJson(response, JsonObject.class);
                    JsonArray objects = jsonObject1.get("items").getAsJsonArray();

                    for (JsonElement i : objects) {
                        Song song = new Song();
                        song.setSong_name(i.getAsJsonObject().get("name").getAsString());
                        song.setSong_id(i.getAsJsonObject().get("id").getAsString());

                        dataBase.insert_to_songs(song.getSong_name(), song.getSong_id(), dbPath);

                }
            }
        }
    }
}

